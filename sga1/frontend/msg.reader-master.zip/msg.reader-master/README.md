# MSG Reader

MSG Reader is an Outlook Item File (.msg) reader that is built with HTML5. 

Allows to parse and extract necessary information (attachment included) from .msg file. 


### Online demo

+ https://ykarpovich.github.io/msg.reader/examples/example.html
